I thought that lab 3 was a pretty good exercise for exploring different ways one could structure a website and then begin to said website.

I implemented the asked for features, but I will continue to implement the aspects that I have made room for in order to use this as
a more permanent structure to hold the information and data from this course.

URL: https://afsws.rpi.edu/AFS/home/41/churce3/public_html/iit/

