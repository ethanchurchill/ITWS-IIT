Ethan Churchill IIT Lab 2

Progress was slow at first, but after time it went smoothly.
I already had a Resume made, but it was interesting to try to convert it to a different format in HTML/CSS.

I plan on rewording it and making it more visually appealing, then possibly using it as my resume going forward.