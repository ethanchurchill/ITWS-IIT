Link to Lab: https://afsws.rpi.edu/AFS/home/41/churce3/public_html/iit/labs/lab4/lab4.html

Instead of putting the lab in the projects page, I just put both of them in my Lab 4 folder that I had made.